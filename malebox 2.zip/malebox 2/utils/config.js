module.exports = {

    db: {
        user: 'db_a779d2_proj5_admin',
        password: 'P6Q6Ehc8HqvarLUA',
        server: 'sql5105.site4now.net',
        database: 'db_a779d2_proj5',
        options: {
            enableArithAbort: true ,
            trustServerCertificate:true
        }
    }
}